package Engine;

import javax.swing.*;
import java.awt.*;

public class GameModeMenu extends JDialog {

    private String selectedMode = null; // �������ѡ��Ķ�սģʽ

    public GameModeMenu(Frame parent) {
        super(parent, "ѡ���սģʽ", true); // ����Ϊģ̬����
        setLayout(new BorderLayout());
        setSize(400, 300);
        setLocationRelativeTo(parent);

        // ����
        JLabel title = new JLabel("ѡ���սģʽ", JLabel.CENTER);
        title.setFont(new Font("TimesRoman", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        // ģʽ��ť
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        addModeButton(buttonPanel, "���˶�ս", "single");
        addModeButton(buttonPanel, "˫�˺���", "cooperative");
        addModeButton(buttonPanel, "˫�˶�ս", "versus");
        add(buttonPanel, BorderLayout.CENTER);

        // �˳���ť
        JButton exitButton = new JButton("�˳���Ϸ");
        exitButton.addActionListener(e -> System.exit(0));
        add(exitButton, BorderLayout.SOUTH);
    }

    private void addModeButton(JPanel panel, String label, String mode) {
        JButton button = new JButton(label);
        button.setFont(new Font("TimesRoman", Font.BOLD, 18));
        button.addActionListener(e -> {
            selectedMode = mode; // ����ѡ���ģʽ
            dispose(); // �رղ˵�
        });
        panel.add(button);
    }

    public String getSelectedMode() {
        return selectedMode;
    }
}
