package Engine;

import javax.swing.*;
import java.awt.*;

public class GameLevelMenu extends JDialog {

    private String selectedMode = null; // ���ڱ���ѡ���ģʽ

    public GameLevelMenu(Frame parent) {
        super(parent, "ѡ����Ϸģʽ", true); // ����Ϊģ̬����
        setLayout(new BorderLayout());
        setSize(400, 300);
        setLocationRelativeTo(parent);

        // ����
        JLabel title = new JLabel("ѡ����Ϸģʽ", JLabel.CENTER);
        title.setFont(new Font("TimesRoman", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        // ģʽ��ť
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        addModeButton(buttonPanel, "ģʽ 1", "level1");
        addModeButton(buttonPanel, "ģʽ 2", "level2");
        addModeButton(buttonPanel, "ģʽ 3", "level3");
        addModeButton(buttonPanel, "ģʽ 4", "level4");
        add(buttonPanel, BorderLayout.CENTER);

        // �˳���ť
        JButton exitButton = new JButton("�˳���Ϸ");
        exitButton.addActionListener(e -> System.exit(0));
        add(exitButton, BorderLayout.SOUTH);
    }

    private void addModeButton(JPanel panel, String label, String mode) {
        JButton button = new JButton(label);
        button.setFont(new Font("TimesRoman", Font.BOLD, 18));
        button.addActionListener(e -> {
            selectedMode = mode; // ����ѡ���ģʽ
            dispose(); // �رղ˵�
        });
        panel.add(button);
    }

    public String getSelectedMode() {
        return selectedMode;
    }
}
